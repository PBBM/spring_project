package com.projetAl.microservice_user;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviceUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
